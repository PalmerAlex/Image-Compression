Submission split into 3 folders,

Report includes the report as docx and PDF

Code includes the raw pycharm code with the according folders necessary.
In order to run the program, please enter images into the images_before_compression.
Otherwise, the dictionary of images will be empty and you will not be able to select any images
The raw images are not attached as it would result in a large submission file.
You can download the images from blackboard assesment section group coursework 2

The allocation folder includes the allocaiton sheet for our report

Report by 29015642, 29021376